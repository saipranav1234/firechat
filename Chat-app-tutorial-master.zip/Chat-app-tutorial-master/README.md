# Chat-app-tutorial
## Real-Time Chatting app in Django with Channels. (Whatsapp Web Clone)
You can chat with multiple persons by staying on the same page.

Explanation for this repository : https://youtu.be/205tbCUl4Uk
